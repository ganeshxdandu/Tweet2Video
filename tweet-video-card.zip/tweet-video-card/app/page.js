'use client';
import { useRef, useState } from 'react';

const THEMES = {
  Light: { bg: '#ffffff', text: '#0f1419', sub: '#536471', line: '#eff3f4' },
  Dim: { bg: '#15202b', text: '#f7f9f9', sub: '#8b98a5', line: '#38444d' },
  Dark: { bg: '#000000', text: '#e7e9ea', sub: '#71767b', line: '#2f3336' },
};
const SANS = '-apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
const font = (px, w = 400) => `${w} ${px}px ${SANS}`;
const prox = (u) => `/api/proxy?url=${encodeURIComponent(u)}`;
const compact = new Intl.NumberFormat('en', { notation: 'compact' });

function loadImg(url) {
  return new Promise((res) => {
    const go = (src, next) => {
      const i = new Image();
      i.crossOrigin = 'anonymous';
      i.onload = () => res(i);
      i.onerror = () => (next ? next() : res(null));
      i.src = src;
    };
    go(url, () => go(prox(url)));
  });
}

function loadVideo(url) {
  return new Promise((res, rej) => {
    const go = (src, next) => {
      const v = document.createElement('video');
      v.crossOrigin = 'anonymous';
      v.playsInline = true;
      v.preload = 'auto';
      v.onloadeddata = () => res(v);
      v.onerror = () => (next ? next() : rej(new Error('The video could not be loaded.')));
      v.src = src;
      v.load();
    };
    go(url, () => go(prox(url)));
  });
}

function wrap(ctx, text, maxW) {
  const out = [];
  for (const para of text.split('\n')) {
    if (!para) { out.push(''); continue; }
    let line = '';
    for (const word of para.split(' ')) {
      const test = line ? `${line} ${word}` : word;
      if (ctx.measureText(test).width <= maxW) { line = test; continue; }
      if (line) out.push(line);
      line = '';
      if (ctx.measureText(word).width <= maxW) { line = word; continue; }
      for (const ch of Array.from(word)) { // very long words / CJK
        if (ctx.measureText(line + ch).width > maxW) { out.push(line); line = ch; } else line += ch;
      }
    }
    out.push(line);
  }
  return out;
}

function makePlan(data, avatar, video, theme) {
  const W = 1080, P = 48, inner = W - P * 2, AV = 96, LH = 62;
  const ctx = document.createElement('canvas').getContext('2d');
  ctx.font = font(44);
  const lines = data.text ? wrap(ctx, data.text, inner) : [];

  const ar = video.videoWidth / video.videoHeight;
  let vh = Math.min(Math.round(inner / ar), 1300);
  let vw = Math.round(vh * ar);
  vw -= vw % 2; vh -= vh % 2;

  let y = P + AV + 28;
  const textY = y;
  y += lines.length ? lines.length * LH + 24 : 0;
  const vy = y;
  y += vh + 28;
  const timeY = y + 30;
  y += 30 + 28;
  const divY = y;
  y += 24;
  const metricsY = y + 34;
  y += 34 + P;
  const H = y + (y % 2);

  return { W, H, P, AV, LH, lines, textY, vx: Math.round((W - vw) / 2), vy, vw, vh, timeY, divY, metricsY, data, avatar, video, theme };
}

function draw(ctx, p) {
  const { W, H, P, AV, LH, data, theme: t } = p;
  ctx.fillStyle = t.bg;
  ctx.fillRect(0, 0, W, H);
  ctx.textBaseline = 'alphabetic';

  // avatar
  ctx.save();
  ctx.beginPath(); ctx.arc(P + AV / 2, P + AV / 2, AV / 2, 0, Math.PI * 2); ctx.clip();
  if (p.avatar) ctx.drawImage(p.avatar, P, P, AV, AV);
  else { ctx.fillStyle = t.line; ctx.fillRect(P, P, AV, AV); }
  ctx.restore();

  // name + badge + handle
  const nx = P + AV + 24;
  ctx.fillStyle = t.text; ctx.font = font(36, 700);
  ctx.fillText(data.name, nx, P + 40);
  if (data.verified) {
    const bx = nx + ctx.measureText(data.name).width + 24, by = P + 28;
    ctx.fillStyle = '#1d9bf0';
    ctx.beginPath(); ctx.arc(bx, by, 15, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = 4; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    ctx.beginPath(); ctx.moveTo(bx - 7, by + 1); ctx.lineTo(bx - 2, by + 6); ctx.lineTo(bx + 8, by - 6); ctx.stroke();
  }
  ctx.fillStyle = t.sub; ctx.font = font(32);
  ctx.fillText(`@${data.handle}`, nx, P + 84);

  // X mark
  ctx.fillStyle = t.text; ctx.font = font(52, 800); ctx.textAlign = 'right';
  ctx.fillText('𝕏', W - P, P + 52); ctx.textAlign = 'left';

  // text
  ctx.fillStyle = t.text; ctx.font = font(44);
  p.lines.forEach((l, i) => ctx.fillText(l, P, p.textY + 44 + i * LH));

  // video
  ctx.save();
  ctx.beginPath(); ctx.roundRect(p.vx, p.vy, p.vw, p.vh, 32); ctx.clip();
  ctx.fillStyle = '#000'; ctx.fillRect(p.vx, p.vy, p.vw, p.vh);
  ctx.drawImage(p.video, p.vx, p.vy, p.vw, p.vh);
  ctx.restore();
  ctx.strokeStyle = t.line; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.roundRect(p.vx, p.vy, p.vw, p.vh, 32); ctx.stroke();

  // time
  ctx.fillStyle = t.sub; ctx.font = font(30);
  const when = new Date(data.createdAt).toLocaleString('en-US', {
    hour: 'numeric', minute: '2-digit', month: 'short', day: 'numeric', year: 'numeric',
  });
  ctx.fillText(when, P, p.timeY);

  // divider + metrics
  ctx.fillStyle = t.line; ctx.fillRect(P, p.divY, W - P * 2, 2);
  ctx.font = font(32, 700); ctx.fillStyle = t.text;
  const likes = compact.format(data.likes), replies = compact.format(data.replies);
  let x = P;
  ctx.fillText(replies, x, p.metricsY);
  x += ctx.measureText(replies).width + 10;
  ctx.font = font(32); ctx.fillStyle = t.sub; ctx.fillText('Replies', x, p.metricsY);
  x += ctx.measureText('Replies').width + 40;
  ctx.font = font(32, 700); ctx.fillStyle = t.text; ctx.fillText(likes, x, p.metricsY);
  x += ctx.measureText(likes).width + 10;
  ctx.font = font(32); ctx.fillStyle = t.sub; ctx.fillText('Likes', x, p.metricsY);
}

function pickMime() {
  const opts = [
    'video/mp4;codecs=avc1.42E01E,mp4a.40.2',
    'video/mp4',
    'video/webm;codecs=vp9,opus',
    'video/webm;codecs=vp8,opus',
    'video/webm',
  ];
  return opts.find((m) => window.MediaRecorder && MediaRecorder.isTypeSupported(m));
}

export default function Home() {
  const canvasRef = useRef(null);
  const state = useRef({});
  const [link, setLink] = useState('');
  const [theme, setTheme] = useState('Light');
  const [status, setStatus] = useState('idle'); // idle | loading | ready | recording
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [file, setFile] = useState(null);

  const render = (t = theme) => {
    const s = state.current;
    if (!s.data) return;
    const plan = makePlan(s.data, s.avatar, s.video, THEMES[t]);
    const c = canvasRef.current;
    c.width = plan.W; c.height = plan.H;
    s.plan = plan;
    draw(c.getContext('2d'), plan);
  };

  async function fetchTweet(e) {
    e.preventDefault();
    setError(''); setFile(null); setProgress(0); setStatus('loading');
    try {
      const r = await fetch(`/api/tweet?url=${encodeURIComponent(link.trim())}`);
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || 'Something went wrong.');
      const [avatar, video] = await Promise.all([loadImg(data.avatar), loadVideo(data.video.url)]);
      state.current = { data, avatar, video };
      setStatus('ready');
      requestAnimationFrame(() => render());
    } catch (err) {
      setError(err.message);
      setStatus('idle');
    }
  }

  function pickTheme(t) {
    setTheme(t);
    setFile(null);
    if (state.current.data) render(t);
  }

  async function record() {
    const s = state.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const mime = pickMime();
    if (!mime) { setError('This browser cannot record video. Try Chrome, Edge, or Safari 14.1+.'); return; }

    setError(''); setFile(null); setProgress(0); setStatus('recording');
    const v = s.video;
    v.currentTime = 0;
    v.muted = false;

    const stream = canvas.captureStream(30);
    const vs = (v.captureStream || v.mozCaptureStream)?.call(v);
    vs?.getAudioTracks().forEach((t) => stream.addTrack(t));

    const chunks = [];
    const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 8_000_000 });
    rec.ondataavailable = (ev) => ev.data.size && chunks.push(ev.data);
    rec.onstop = () => {
      const type = mime.split(';')[0];
      const blob = new Blob(chunks, { type });
      setFile({ url: URL.createObjectURL(blob), ext: type.includes('mp4') ? 'mp4' : 'webm' });
      setStatus('ready');
    };

    let raf;
    const loop = () => {
      draw(ctx, s.plan);
      setProgress(v.duration ? v.currentTime / v.duration : 0);
      if (!v.ended) raf = requestAnimationFrame(loop);
    };
    v.onended = () => {
      cancelAnimationFrame(raf);
      draw(ctx, s.plan);
      setProgress(1);
      setTimeout(() => rec.stop(), 250);
    };

    try {
      rec.start(250);
      await v.play();
      loop();
    } catch {
      rec.state !== 'inactive' && rec.stop();
      setError('Playback was blocked. Tap the button again.');
      setStatus('ready');
    }
  }

  const busy = status === 'loading' || status === 'recording';

  return (
    <main className="shell">
      <section>
        <h1>Tweet video card</h1>
        <p className="lede">Paste a tweet link and download its video inside the tweet, avatar and all.</p>

        <form onSubmit={fetchTweet}>
          <label className="field" htmlFor="link">Tweet link</label>
          <div className="row">
            <input
              id="link" type="text" inputMode="url" autoComplete="off"
              placeholder="https://x.com/user/status/…"
              value={link} onChange={(e) => setLink(e.target.value)}
            />
            <button type="submit" disabled={busy || !link.trim()}>
              {status === 'loading' ? 'Loading…' : 'Load'}
            </button>
          </div>
        </form>

        {error && <p className="error" role="alert">{error}</p>}

        <div className="themes" role="group" aria-label="Card theme">
          {Object.keys(THEMES).map((t) => (
            <button key={t} type="button" aria-pressed={theme === t} onClick={() => pickTheme(t)} disabled={status === 'recording'}>
              {t}
            </button>
          ))}
        </div>

        <button className="primary" onClick={record} disabled={status !== 'ready'}>
          {status === 'recording' ? `Recording… ${Math.round(progress * 100)}%` : 'Create video'}
        </button>

        {status === 'recording' && (
          <div className="progress" aria-hidden><div style={{ width: `${progress * 100}%` }} /></div>
        )}

        {file && (
          <a className="download" href={file.url} download={`tweet-${state.current.data.id}.${file.ext}`}>
            Download .{file.ext}
          </a>
        )}

        <p className="hint">
          The video is recorded in real time, so it takes as long as the clip. Keep this tab open until it finishes.
        </p>
      </section>

      <section className="stage" aria-live="polite">
        {state.current.data && status !== 'idle' ? (
          <canvas ref={canvasRef} />
        ) : (
          <p className="empty">Your tweet card appears here once you load a link.</p>
        )}
      </section>
    </main>
  );
}
