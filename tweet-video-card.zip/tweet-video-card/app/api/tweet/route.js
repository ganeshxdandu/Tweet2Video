const decode = (s) =>
  s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
   .replace(/&quot;/g, '"').replace(/&#39;/g, "'");

const fail = (error, status) => Response.json({ error }, { status });

export async function GET(req) {
  const link = new URL(req.url).searchParams.get('url') || '';
  const m =
    link.match(/(?:twitter\.com|x\.com)\/[^/]+\/status(?:es)?\/(\d+)/i) ||
    link.match(/^(\d{8,25})$/);
  if (!m) return fail('Paste a full tweet link, like https://x.com/user/status/123456789', 400);

  const id = m[1];
  const token = ((Number(id) / 1e15) * Math.PI).toString(36).replace(/(0+|\.)/g, '');

  let r;
  try {
    r = await fetch(
      `https://cdn.syndication.twimg.com/tweet-result?id=${id}&lang=en&token=${token}`,
      { headers: { 'User-Agent': 'Mozilla/5.0' }, cache: 'no-store' }
    );
  } catch {
    return fail('Could not reach Twitter. Try again in a moment.', 502);
  }
  if (r.status === 404) return fail('Tweet not found. It may be deleted or from a private account.', 404);
  if (!r.ok) return fail('Twitter did not return this tweet. Try again in a moment.', 502);

  let t;
  try { t = await r.json(); } catch { return fail('Unexpected response from Twitter.', 502); }
  if (!t || t.__typename === 'TweetTombstone' || !t.user)
    return fail('This tweet is unavailable.', 404);

  const media = (t.mediaDetails || []).find((x) => x.type === 'video' || x.type === 'animated_gif');
  if (!media) return fail('This tweet has no video.', 422);

  const variants = (media.video_info?.variants || [])
    .filter((v) => v.content_type === 'video/mp4')
    .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
  if (!variants.length) return fail('No downloadable video found in this tweet.', 422);

  const chars = Array.from(t.text || '');
  const range = t.display_text_range || [0, chars.length];
  let text = chars.slice(range[0], range[1]).join('');
  for (const u of t.entities?.urls || []) text = text.replace(u.url, u.display_url);
  text = decode(text).trim();

  return Response.json({
    id,
    name: t.user.name,
    handle: t.user.screen_name,
    avatar: (t.user.profile_image_url_https || '').replace('_normal', '_400x400'),
    verified: !!(t.user.is_blue_verified || t.user.verified),
    text,
    createdAt: t.created_at,
    likes: t.favorite_count || 0,
    replies: t.conversation_count || 0,
    video: {
      url: variants[0].url,
      poster: media.media_url_https,
      gif: media.type === 'animated_gif',
    },
  });
}
