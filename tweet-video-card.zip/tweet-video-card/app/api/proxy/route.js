// Streams Twitter media through your server so the canvas is never blocked by CORS.
export async function GET(req) {
  const u = new URL(req.url).searchParams.get('url');
  let target;
  try { target = new URL(u); } catch { return new Response('Bad URL', { status: 400 }); }
  if (target.protocol !== 'https:' || !/(^|\.)twimg\.com$/.test(target.hostname))
    return new Response('Forbidden', { status: 403 });

  const r = await fetch(target, { headers: { 'User-Agent': 'Mozilla/5.0' } });
  return new Response(r.body, {
    status: r.status,
    headers: {
      'Content-Type': r.headers.get('content-type') || 'application/octet-stream',
      'Cache-Control': 'public, max-age=3600',
    },
  });
}
